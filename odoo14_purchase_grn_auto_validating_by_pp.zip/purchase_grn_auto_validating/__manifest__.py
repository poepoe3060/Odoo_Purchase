{
    'name': 'Purchase GRN Auto Validating',
    'version': '1.1',
    'category': 'Receipt',
    'summary': 'Purchase Receipt Management',
    'description': """
    This module contains the modification about purchase receipt.
    """,
    'depends':  ['base','purchase'],
    'data': [

        'views/res_config_view_form_inherit.xml',

    ],

    'installable': True,
    'auto_install': False
}
